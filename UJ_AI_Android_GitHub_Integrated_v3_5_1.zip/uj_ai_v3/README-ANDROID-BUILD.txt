UJ AI Android build package

This package contains the UJ AI web/PWA app, Capacitor Android configuration, and a GitHub Actions workflow.

To build the APK:
1. Extract this ZIP and upload the CONTENTS of the `uj_ai_v3` folder (not the outer folder itself) to the root of your GitHub repository; keep `.github/workflows/build-android.yml`.
2. Commit the files to the main branch.
3. Open the repository's Actions tab and run "Build UJ AI Android APK" (or let the push workflow run).
4. When the workflow succeeds, open its run, find Artifacts, and download UJ-AI-debug-apk.
5. Extract the artifact ZIP to get app-debug.apk. Install it on your Android phone.

Important:
- This is a DEBUG APK build workflow, not a signed Play Store release.
- The app's AI chat requires at least one server-side provider key (Gemini/OpenAI/Meta) configured on a secure Node.js host. Do not put API keys in the Android app or commit them to GitHub.
- HeyGen, Metricool and vidIQ require their own authorized credentials and plans.
- The current APK wraps the web UI. Server API calls require the Node backend to be deployed and the app configured to reach its HTTPS URL; this build does not itself host the backend.
- Verify backend URL configuration and live integrations before considering it production-ready.

GitHub integration:
- The app includes a GitHub Connect tile and OAuth callback.
- Configure GITHUB_CLIENT_ID, GITHUB_CLIENT_SECRET and GITHUB_CALLBACK_URL as private server environment variables.
- In the GitHub OAuth App, set the Authorization callback URL to the exact HTTPS callback URL above.
- This starter integration requests only `read:user` and lists public repositories. It does not read private repositories or write to repositories.
- OAuth tokens remain server-side in process memory and are not sent to the browser. Deploy behind HTTPS. For production, use persistent encrypted sessions and an app-level login.
