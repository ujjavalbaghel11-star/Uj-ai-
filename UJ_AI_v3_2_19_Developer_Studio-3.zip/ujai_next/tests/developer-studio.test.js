import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

test('Developer Studio provides file explorer, editor, UJ handoff and safe terminal preview', () => {
  const html = fs.readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  const js = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
  const css = fs.readFileSync(new URL('../public/app.css', import.meta.url), 'utf8');
  for (const id of ['devFileTree', 'devCodeEditor', 'devAskAi', 'devTerminalOutput', 'devRunCheck']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(js, /function renderDevFileTree\(/);
  assert.match(js, /No shell commands were run/);
  assert.match(css, /\.dev-studio-grid/);
});
