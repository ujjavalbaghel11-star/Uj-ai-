UJ AI — PERSONAL VOICE ASSISTANT — VERSION 3.4

WHAT IS IMPLEMENTED IN THIS BUILD
- Responsive Progressive Web App (PWA) for Android, iPhone and desktop browsers.
- UJ-branded browser voice input (SpeechRecognition where supported) and Hindi voice output (SpeechSynthesis).
- Personal, Nursing Study, Coding and Voice Agent chat modes.
- Three server-side chat providers: Gemini, OpenAI and Meta Model API.
- Silent automatic failover: the backend tries configured providers in sequence and never returns the selected provider name to the browser.
- HeyGen Video 1 v3 API connector: submit a text-to-video job and poll its status.
- Metricool API connector: list brands, list scheduled posts, read supported network post analytics, and schedule a post after explicit confirmation.
- vidIQ hosted MCP connector proxy. API-key mode is read-only; account edits require an OAuth-enabled MCP client and user authorization.
- Basic security headers, request size limit, API rate limiting and defensive self-audit.
- All third-party keys are read from server-side environment variables. Never put keys in HTML, GitHub or chat.

IMPORTANT: WHAT STILL REQUIRES ACCOUNT SETUP / LIVE VERIFICATION
This is an integration-ready build, not a claim that external accounts are already connected. A live call cannot succeed until the matching private keys/IDs are configured and the account has access/credits/permissions.
- Meta Model API key is created in the Meta Model API dashboard; env: META_MODEL_API_KEY. Default model: muse-spark-1.3.
- HeyGen API key is created in the HeyGen developer dashboard; env: HEYGEN_API_KEY. Video creation can use paid API credits. API endpoints follow HeyGen v3.
- vidIQ MCP API key is created in vidIQ Account Settings > MCP; env: VIDIQ_MCP_API_KEY. API-key connection is read-only. Changes to a user's videos require an OAuth-enabled MCP client and explicit account consent.
- Metricool API is available on Advanced and Custom plans. Configure METRICOOL_API_TOKEN, METRICOOL_USER_ID and METRICOOL_BLOG_ID. Scheduling endpoint is guarded by confirm=true.
- At least one of GEMINI_API_KEY, OPENAI_API_KEY or META_MODEL_API_KEY must be configured for AI chat. Configure more than one to enable failover.

API ROUTES
GET  /api/health
GET  /api/integrations/status
POST /api/chat                 { message, history?, mode? }
POST /api/agent                { command, history? }
POST /api/integrations/heygen/videos
GET  /api/integrations/heygen/videos/:id
GET  /api/integrations/metricool/brands
GET  /api/integrations/metricool/posts?from=ISO&to=ISO&timezone=Asia/Kolkata
GET  /api/integrations/metricool/analytics/:network?from=ISO&to=ISO
POST /api/integrations/metricool/posts { post, confirm:true, jobId? }
POST /api/integrations/vidiq/mcp      JSON-RPC MCP request (API-key mode)

RUN LOCALLY
1. Install Node.js 20 or newer.
2. Extract the ZIP and open a terminal in the uj_ai_v3 folder.
3. Run: npm install
4. Copy .env.example to .env and add provider keys locally, or configure them in your host's private environment/secrets settings.
5. Run: npm start
6. Open http://localhost:3000. For microphone/PWA installation on a phone, deploy behind HTTPS.

TESTING STATUS
- server.js Node syntax check: passed during packaging.
- Inline browser JavaScript parse check: passed during packaging.
- ZIP archive integrity check: run after packaging.
- Live third-party API calls: NOT run; no user API keys or account authorization were supplied.
- Native Android APK: NOT included in this ZIP. This remains a browser-installable PWA build, not a verified native APK.

SECURITY / PRODUCTION LIMITATIONS
- The existing rate limiter and event log are in-memory and per process.
- No production user login/session system or persistent database is included.
- Deploy behind HTTPS; add managed persistent rate limiting, database-backed logs, backups, privacy policy and security review before public launch.
- Do not use this starter for sensitive patient information or private messages.
- A PWA cannot read other apps' private messages or silently control the phone. Those require separate native Android features and explicit permissions.
