import express from 'express';
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { randomUUID } from 'node:crypto';

dotenv.config();
const app = express();
const here = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
app.disable('x-powered-by');
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), geolocation=(), payment=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('Cache-Control', 'no-store');
  next();
});
app.use(express.json({ limit: '40kb' }));

const rateWindows = new Map();
const securityEvents = [];
function recordSecurityEvent(type) {
  securityEvents.unshift({ type, at: new Date().toISOString() });
  if (securityEvents.length > 30) securityEvents.length = 30;
}
function apiRateLimit(req, res, next) {
  const key = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  let item = rateWindows.get(key);
  if (!item || now - item.start >= 10 * 60 * 1000) item = { start: now, count: 0 };
  item.count += 1;
  rateWindows.set(key, item);
  if (item.count > 20) {
    recordSecurityEvent('API rate limit triggered');
    return res.status(429).json({ error: 'बहुत अधिक requests। 10 मिनट बाद फिर कोशिश करें।' });
  }
  next();
}
app.use(['/api/chat', '/api/agent', '/api/integrations'], apiRateLimit);
app.use(express.static(path.join(here, 'public'), { extensions: ['html'] }));

const SYSTEM = {
  personal: 'You are UJ AI, a capable Hindi/Hinglish personal assistant. Help plan and complete digital tasks when tools are actually available. Be honest about what you can and cannot execute. Never claim an external action, upload, message, purchase, or deployment happened unless a connected authorized tool confirms it. Ask for confirmation before sending messages, publishing posts, sharing files, or other external side effects. Do not request passwords, OTPs, or API keys in chat.',
  nursing: 'You are UJ AI Nursing Study Tutor. Teach nursing concepts clearly for education. Do not diagnose or prescribe. For real patient care, direct the user to qualified clinical supervision and local protocols.',
  coding: 'You are UJ AI Coding Assistant. Explain and create code step by step. Never claim code was run or tested unless it actually was.',
  agent: 'You are UJ AI Voice Agent. Interpret the user’s spoken or typed command, make a practical step-by-step plan, and state which steps you can perform in this deployment. You do not have arbitrary access to the phone, other apps, contacts, messages, camera, or social accounts. Never claim an action was executed unless a real connected tool confirms it. Before sending a message or publishing content, show the exact content and require explicit confirmation. Never ask for passwords or OTPs.'
};
const cleanHistory = history => Array.isArray(history)
  ? history.slice(-12).filter(m => ['user', 'assistant'].includes(m?.role))
      .map(m => ({ role: m.role, content: String(m.content ?? '').slice(0, 4000) })) : [];

async function readJson(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error?.message || data.message || `Provider HTTP ${response.status}`);
  return data;
}
async function askGemini(message, history, mode) {
  if (!process.env.GEMINI_API_KEY) throw new Error('not configured');
  const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  const contents = [...history, { role: 'user', content: message }].map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }]
  }));
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM[mode] || SYSTEM.personal }] }, contents,
      generationConfig: { temperature: 0.65, maxOutputTokens: 1600 } })
  });
  const data = await readJson(response);
  const answer = data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();
  if (!answer) throw new Error('empty response');
  return answer;
}
async function askOpenAICompatible({ baseUrl, apiKey, model, message, history, mode }) {
  const messages = [{ role: 'system', content: SYSTEM[mode] || SYSTEM.personal }, ...history, { role: 'user', content: message }];
  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, messages, temperature: 0.65, max_tokens: 1600 })
  });
  const data = await readJson(response);
  const answer = data.choices?.[0]?.message?.content?.trim();
  if (!answer) throw new Error('empty response');
  return answer;
}
async function askOpenAI(message, history, mode) {
  if (!process.env.OPENAI_API_KEY) throw new Error('not configured');
  return askOpenAICompatible({ baseUrl: 'https://api.openai.com/v1', apiKey: process.env.OPENAI_API_KEY,
    model: process.env.OPENAI_MODEL || 'gpt-4o-mini', message, history, mode });
}
async function askMeta(message, history, mode) {
  if (!process.env.META_MODEL_API_KEY) throw new Error('not configured');
  return askOpenAICompatible({ baseUrl: 'https://api.meta.ai/v1', apiKey: process.env.META_MODEL_API_KEY,
    model: process.env.META_MODEL || 'muse-spark-1.3', message, history, mode });
}
async function getReply(message, history, mode) {
  // Silent automatic failover: the app never returns or displays the provider name.
  const providers = [askGemini, askOpenAI, askMeta];
  for (const provider of providers) {
    try { return { reply: await provider(message, history, mode) }; }
    catch { /* try the next configured provider without exposing switch details */ }
  }
  const err = new Error('UJ AI का कोई AI connection अभी उपलब्ध नहीं है। Server पर कम-से-कम एक provider key configure करनी होगी।');
  err.status = 503;
  throw err;
}

// HeyGen Video 1 (v3 API). API key is kept only on the server.
async function heygenRequest(route, options = {}) {
  if (!process.env.HEYGEN_API_KEY) throw new Error('HeyGen अभी configure नहीं है।');
  const response = await fetch(`https://api.heygen.com${route}`, {
    ...options,
    headers: { 'X-Api-Key': process.env.HEYGEN_API_KEY, ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) }
  });
  return readJson(response);
}
app.get('/api/integrations/status', (_req, res) => res.json({
  ai: Boolean(process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY || process.env.META_MODEL_API_KEY),
  voice: true,
  heygen: Boolean(process.env.HEYGEN_API_KEY),
  vidiq: Boolean(process.env.VIDIQ_MCP_API_KEY),
  metricool: Boolean(process.env.METRICOOL_API_TOKEN && process.env.METRICOOL_USER_ID && process.env.METRICOOL_BLOG_ID)
}));
app.post('/api/integrations/heygen/videos', async (req, res) => {
  if (req.body?.confirm !== true) return res.status(428).json({ error: 'Video render credits use हो सकते हैं। आगे बढ़ने से पहले confirm=true के साथ स्पष्ट पुष्टि जरूरी है।' });
  const { prompt, duration = 8, aspect_ratio = '9:16', resolution = '768p' } = req.body || {};
  if (typeof prompt !== 'string' || prompt.trim().length < 8 || prompt.length > 32000)
    return res.status(400).json({ error: 'Prompt 8–32000 characters का होना चाहिए।' });
  if (!Number.isInteger(duration) || duration < 5 || duration > 30)
    return res.status(400).json({ error: 'Duration 5 से 30 seconds के बीच integer होना चाहिए।' });
  if (!['9:16', '16:9', '1:1', '4:3', '3:4', '21:9'].includes(aspect_ratio))
    return res.status(400).json({ error: 'Aspect ratio supported नहीं है।' });
  if (!['480p', '768p', '1080p', '2k'].includes(resolution))
    return res.status(400).json({ error: 'Resolution supported नहीं है।' });
  try {
    const data = await heygenRequest('/v3/models/videos', { method: 'POST', headers: { 'Idempotency-Key': randomUUID() },
      body: JSON.stringify({ model: 'heygen-video-1', mode: 'text_to_video', prompt: prompt.trim(), duration, aspect_ratio, resolution }) });
    res.status(202).json(data);
  } catch (error) { res.status(502).json({ error: error.message }); }
});
app.get('/api/integrations/heygen/videos/:id', async (req, res) => {
  if (!/^[A-Za-z0-9_-]{5,160}$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid video id.' });
  try { res.json(await heygenRequest(`/v3/models/videos/${encodeURIComponent(req.params.id)}`)); }
  catch (error) { res.status(502).json({ error: error.message }); }
});

// Metricool API uses X-Mc-Auth plus userId and blogId query parameters.
function metricoolUrl(route, extra = {}) {
  const url = new URL(`https://app.metricool.com/api${route}`);
  url.searchParams.set('userId', process.env.METRICOOL_USER_ID || '');
  url.searchParams.set('blogId', process.env.METRICOOL_BLOG_ID || '');
  for (const [key, value] of Object.entries(extra)) if (value !== undefined && value !== null) url.searchParams.set(key, String(value));
  return url;
}
async function metricoolRequest(route, { method = 'GET', body, query = {} } = {}) {
  if (!process.env.METRICOOL_API_TOKEN || !process.env.METRICOOL_USER_ID || !process.env.METRICOOL_BLOG_ID)
    throw new Error('Metricool token, user ID और blog ID configure करना बाकी है।');
  const response = await fetch(metricoolUrl(route, query), { method,
    headers: { 'X-Mc-Auth': process.env.METRICOOL_API_TOKEN, ...(body ? { 'Content-Type': 'application/json' } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}) });
  if (!response.ok) { const problem = await response.json().catch(() => ({})); throw new Error(problem.error?.message || problem.message || `Metricool HTTP ${response.status}`); }
  const type = response.headers.get('content-type') || '';
  return type.includes('application/json') ? response.json() : { contentType: type, data: await response.text() };
}
app.get('/api/integrations/metricool/brands', async (_req, res) => {
  try { res.json(await metricoolRequest('/admin/profiles-auth')); }
  catch (error) { res.status(502).json({ error: error.message }); }
});
app.get('/api/integrations/metricool/posts', async (req, res) => {
  const { from, to, timezone = 'Asia/Kolkata' } = req.query;
  if (!from || !to) return res.status(400).json({ error: 'from और to date देना जरूरी है।' });
  try { res.json(await metricoolRequest('/v2/scheduler/posts', { query: { from, to, timezone } })); }
  catch (error) { res.status(502).json({ error: error.message }); }
});
app.get('/api/integrations/metricool/analytics/:network', async (req, res) => {
  const allowed = new Set(['instagram', 'facebook', 'linkedin', 'pinterest', 'threads', 'tiktok', 'twitter', 'bluesky']);
  const network = req.params.network.toLowerCase();
  const { from, to, timezone = 'Asia/Kolkata' } = req.query;
  if (!allowed.has(network)) return res.status(400).json({ error: 'Unsupported analytics network.' });
  if (!from || !to) return res.status(400).json({ error: 'from और to date देना जरूरी है।' });
  try { res.json(await metricoolRequest(`/v2/analytics/posts/${network}`, { query: { from, to, timezone } })); }
  catch (error) { res.status(502).json({ error: error.message }); }
});
app.post('/api/integrations/metricool/posts', async (req, res) => {
  // Publishing/scheduling is an external side effect: caller must send explicit confirm=true.
  if (req.body?.confirm !== true) return res.status(428).json({ error: 'Schedule/publish करने से पहले confirm=true के साथ स्पष्ट पुष्टि जरूरी है।' });
  const { post, jobId } = req.body || {};
  if (!post || typeof post !== 'object' || Array.isArray(post)) return res.status(400).json({ error: 'Metricool ScheduledPost object जरूरी है।' });
  try { res.json(await metricoolRequest('/v2/scheduler/posts', { method: 'POST', body: post, query: jobId ? { jobId } : {} })); }
  catch (error) { res.status(502).json({ error: error.message }); }
});

// vidIQ remote MCP proxy. API-key mode is read-only; OAuth is required for account changes.
app.post('/api/integrations/vidiq/mcp', async (req, res) => {
  if (!process.env.VIDIQ_MCP_API_KEY) return res.status(503).json({ error: 'vidIQ MCP API key configure करना बाकी है।' });
  try {
    const headers = { Authorization: `Bearer ${process.env.VIDIQ_MCP_API_KEY}`,
      'Content-Type': 'application/json', Accept: req.get('accept') || 'application/json, text/event-stream' };
    for (const name of ['mcp-session-id', 'mcp-protocol-version']) if (req.get(name)) headers[name] = req.get(name);
    const upstream = await fetch('https://mcp.vidiq.com/mcp', { method: 'POST', headers, body: JSON.stringify(req.body) });
    res.status(upstream.status);
    for (const name of ['content-type', 'mcp-session-id', 'mcp-protocol-version']) {
      const value = upstream.headers.get(name); if (value) res.setHeader(name, value);
    }
    if (upstream.body) Readable.fromWeb(upstream.body).pipe(res); else res.end();
  } catch { res.status(502).json({ error: 'vidIQ MCP service अभी उपलब्ध नहीं है।' }); }
});

app.get('/api/security/audit', (_req, res) => {
  const checks = [
    { name: 'Security response headers', ok: true, detail: 'Baseline headers are enabled by the Express middleware.' },
    { name: 'API request throttling', ok: true, detail: 'Chat and agent routes are limited to 20 requests per 10 minutes per source address; in-memory only.' },
    { name: 'Request body limit', ok: true, detail: 'JSON request bodies are limited to 40 KB.' },
    { name: 'Server-side API secrets', ok: true, detail: 'Provider keys are read from server environment variables, not the browser UI.' },
    { name: 'HTTPS deployment', ok: process.env.NODE_ENV === 'production', detail: process.env.NODE_ENV === 'production' ? 'Production mode is set; confirm HTTPS is enforced by your hosting provider.' : 'Not confirmed. Deploy behind HTTPS before using microphone or private data.' },
    { name: 'User authentication', ok: false, detail: 'No real user login/session system is configured in this starter.' },
    { name: 'Persistent audit logs', ok: false, detail: 'Security events are stored in memory and disappear when the server restarts.' },
    { name: 'Managed WAF / edge protection', ok: false, detail: 'No managed web application firewall is configured by this app.' }
  ];
  const passed = checks.filter(c => c.ok).length;
  res.json({ summary: `${passed}/${checks.length} baseline checks currently pass`, checks,
    events: securityEvents.slice(0, 10),
    limitations: ['यह self-audit केवल इस UJ AI server की दिखाई देने वाली configuration जाँचता है; यह penetration test नहीं है।',
      'यह किसी attacker की वास्तविक पहचान या निजी device/location पता नहीं लगा सकता।',
      'Public launch से पहले authentication, HTTPS enforcement, persistent audit storage, backups और managed WAF जोड़ें।'] });
});
app.get('/api/security/status', (_req, res) => res.json({
  protections: { securityHeaders: true, apiRateLimit: true, requestBodyLimit: '40kb', secretsServerSide: true, https: Boolean(process.env.NODE_ENV === 'production') },
  events: securityEvents.slice(0, 10),
  limitations: ['यह basic app-level protection है, पूर्ण anti-hack guarantee नहीं।', 'Events केवल इस server process की memory में रहते हैं और restart पर मिट जाते हैं।', 'Production में HTTPS, मजबूत authentication, database-backed audit logs और managed WAF जरूरी हैं।']
}));
app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'UJ AI', version: '3.4.0',
  aiReady: Boolean(process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY || process.env.META_MODEL_API_KEY),
  features: { chat: true, automaticFailover: true, voiceInBrowser: true, voiceOutput: true, heygenApi: Boolean(process.env.HEYGEN_API_KEY),
    vidiqMcp: Boolean(process.env.VIDIQ_MCP_API_KEY), metricoolApi: Boolean(process.env.METRICOOL_API_TOKEN && process.env.METRICOOL_USER_ID && process.env.METRICOOL_BLOG_ID),
    nativeAndroidApp: false, videoGeneration: Boolean(process.env.HEYGEN_API_KEY), socialScheduling: Boolean(process.env.METRICOOL_API_TOKEN && process.env.METRICOOL_USER_ID && process.env.METRICOOL_BLOG_ID) } }));
app.post('/api/chat', async (req, res) => {
  const { message, history = [], mode = 'personal' } = req.body || {};
  if (typeof message !== 'string' || !message.trim() || message.length > 4000) {
    recordSecurityEvent('Invalid chat request rejected'); return res.status(400).json({ error: 'Message must contain 1–4000 characters.' });
  }
  const safeMode = Object.hasOwn(SYSTEM, mode) ? mode : 'personal';
  try { res.json(await getReply(message.trim(), cleanHistory(history), safeMode)); }
  catch (error) { res.status(error.status || 503).json({ error: error.message }); }
});
app.post('/api/agent', async (req, res) => {
  const { command, history = [] } = req.body || {};
  if (typeof command !== 'string' || !command.trim() || command.length > 4000)
    return res.status(400).json({ error: 'Command must contain 1–4000 characters.' });
  try { res.json({ ...(await getReply(command.trim(), cleanHistory(history), 'agent')), mode: 'agent' }); }
  catch (error) { res.status(error.status || 503).json({ error: error.message }); }
});
app.get('*', (_req, res) => res.sendFile(path.join(here, 'public', 'index.html')));
app.listen(PORT, () => console.log(`UJ AI v3.4 listening on port ${PORT}`));
